class Motor():
	target = 0