from robot import Robot
#from event import wait_for
#from poll import And, Or, Poll
from vision import MARKER_ARENA, MARKER_ROBOT, MARKER_PEDESTAL, MARKER_TOKEN
